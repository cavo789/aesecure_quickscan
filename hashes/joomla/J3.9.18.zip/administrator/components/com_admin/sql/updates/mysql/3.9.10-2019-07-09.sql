ALTER TABLE `#__template_styles` MODIFY `home` char(7) NOT NULL DEFAULT '0';
